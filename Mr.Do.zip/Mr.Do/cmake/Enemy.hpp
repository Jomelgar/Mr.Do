#pragma once

#include "Direction.hpp"
#include <string>
#include <random>
#include <ctime>

using std::string;

class Enemy
{
    public:
    Enemy() : X(0), Y(0) {}
    Enemy(int x, int y) : X(x), Y(y) {}
    
    void setDirection(Direction pos){dir = pos;}
    void changeDirection();
    void setX(int x){X = x;}
    void setY(int y){Y = y;}

    bool isThere(int x, int y){return Y == y && x == X;}    
    int getX(){return X;}
    int getY(){return Y;}
    Direction getDirection(){return dir;}

    private:
    int X, Y;
    Direction dir = Direction::Null;
    string body = "\x6\x7";
};

void Enemy::changeDirection() 
{
    std::srand(std::time(0));
    int random = std::rand() % 4;

    switch(random)
    {
        case 0:
            setDirection(Direction::Left);
        break;
        case 1:
            setDirection(Direction::Right);
        break;
        case 2:
            setDirection(Direction::Up);
        break;
        case 3:
            setDirection(Direction::Down);
        break;
    }
}
#pragma once

#include "TextConsole.h"
#include "Direction.hpp"
#include "Character.hpp"
#include "Proyectile.hpp"
#include "Cherry.hpp"
#include "Apple.hpp"
#include "Enemy.hpp"
#include <string>
#include <iostream>
#include <thread>
#include <chrono>
#include <vector>


using std::string;

int SIZE_X = 30, SIZE_Y = 15;

int Character_SPAWN_X = 14, Character_SPAWN_Y = 13;
int ENEMY_SPAWNER_X = 14 , ENEMY_SPAWNER_Y = 7;
string ENEMY_SPAWNER_BODY = "\x5";

class Map {
public:
    Map(TextConsole *cons);
    Map(const Map&) = delete;
    Map& operator=(const Map&) = delete;
    ~Map() {
        running = false;
        if (actionThread && actionThread->joinable()) {
            actionThread->join();
        }
        for (int i = 0; i < SIZE_X; i++) {
            delete[] space[i];
        }
        delete[] space;
    }

    void MoveCharacter(Direction dir);
    void SeeApples();
    void MoveApple(Apple & app);
    void MoveProyectile();
    void ProyectileCall();
    void Shoot();
    void toString();
    void printData();

private:
    void actionLoop();

    int score = 0, lifes = 3;
    string **space;
    Character character = Character(Character_SPAWN_X, Character_SPAWN_Y);
    Proyectile proyectile;
    TextConsole *con;
    Cherry cherries[8];
    Apple apples[8];
    std::unique_ptr<std::thread> actionThread;
    bool running = true;
    std::vector<Enemy> Enemies;
};

Map::Map(TextConsole *cons) : con(cons)  {
    space = new string *[SIZE_X];
    for (int i = 0; i < SIZE_X; i++) {
        space[i] = new string[SIZE_Y];
        for (int j = 0; j < SIZE_Y; j++) {
            space[i][j] = "  ";
        }
    }

    // Object Spawn
    space[Character_SPAWN_X][Character_SPAWN_Y] = "\x2\x1";

    //Enemy Spawner
    space[ENEMY_SPAWNER_X][ENEMY_SPAWNER_Y] = ENEMY_SPAWNER_BODY;
    
    cherries[0] = Cherry(0,1);
    cherries[1] = Cherry(3,3);
    cherries[2] = Cherry(4,3);
    cherries[3] = Cherry(5,3);
    cherries[4] = Cherry(6,3);
    cherries[5] = Cherry(7,3);
    cherries[6] = Cherry(8,3);
    cherries[7] = Cherry(9,3);        

    apples[0] = Apple(2,0);
    apples[1] = Apple(3,0);
    apples[2] = Apple(4,0);
    apples[3] = Apple(5,0);
    apples[4] = Apple(6,0);
    apples[5] = Apple(7,0);
    apples[6] = Apple(8,0);
    apples[7] = Apple(9,0);

    //Spawn of cherries and apples
    for (int i = 0; i < 8; i++)
    {
        space[cherries[i].getX()][cherries[i].getY()] = "\x9\x10";
        space[apples[i].getX()][apples[i].getY()] = "\x011\x012";
    }
    
    //THE THREAD
    actionThread = std::make_unique<std::thread>(&Map::actionLoop, this);
}

void Map::MoveProyectile()
{
    if(proyectile.getActive())
    {
        if(proyectile.getX() <= 0 && proyectile.getDirection() == Direction::Left
            || proyectile.getX() >= SIZE_X-1 && proyectile.getDirection() == Direction::Right
            || proyectile.getY() <= 0 && proyectile.getDirection() ==Direction::Up 
            || proyectile.getY() >= SIZE_Y-1 && proyectile.getDirection() == Direction::Down)
        {
            proyectile.setActive();
            con->setCursor(proyectile.getY(),proyectile.getX());
            *con << "  ";
        }
        else
        {
            con->setCursor(proyectile.getY(),proyectile.getX());
            space[proyectile.getX()][proyectile.getY()] = "  ";
            *con << space[proyectile.getX()][proyectile.getY()];
                switch(proyectile.getDirection())
                {
                    case Direction::Left:
                        proyectile.setX(proyectile.getX() - 1);
                    break;
                    case Direction::Right:
                        proyectile.setX(proyectile.getX() + 1);
                    break;
                    case Direction::Up:
                        proyectile.setY(proyectile.getY() - 1);
                    break;
                    case Direction::Down:
                        proyectile.setY(proyectile.getY() + 1);
                    break;
                }
                if(space[proyectile.getX()][proyectile.getY()] !=  "  ")
                {
                    proyectile.setActive();
                }else
                {
                    space[proyectile.getX()][proyectile.getY()] = "\x6";
                    con->setCursor(proyectile.getY(),proyectile.getX());
                    *con << space[proyectile.getX()][proyectile.getY()];
                }
        }
    }
}

void Map::actionLoop()
{
    while (running) 
    {
        ProyectileCall();
        SeeApples();
        printData();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void Map::Shoot()
{
    if(proyectile.isTimerReady())
    {
        if(space[proyectile.getX()][proyectile.getY()] == "\x6")
        {
            con->setCursor(proyectile.getY(),proyectile.getX());
            *con << "  ";
        }
        switch (character.getDirection())
        {
        case Direction::Left:
            proyectile = Proyectile(character.getX()-1, character.getY(), character.getDirection());
            break;
        case Direction::Right:
            proyectile = Proyectile(character.getX()+1, character.getY(), character.getDirection());
        break;
        case Direction::Up:
            proyectile = Proyectile(character.getX(), character.getY()-1, character.getDirection());
        break;
        case Direction::Down:
            proyectile = Proyectile(character.getX(), character.getY()+1, character.getDirection());
        break;
        }
        proyectile.setActive();
        MoveProyectile();
    }
}

void Map::ProyectileCall()
{
    MoveProyectile();
}

void Map::toString()
{
    con->setCursor(0,0);
    for (int i = 0; i < SIZE_X; i++)
    {
        for (int j = 0; j < SIZE_Y; j++)
        {
            con->setCursor(j, i);
            *con << space[i][j];
        }
    }
    
    printData();
}

void Map::printData()
{
    con->setCursor(0,40);
    *con << "Score: " << std::to_string(score);
    con->setCursor(3,40);
    *con << "Lifes: " << std::to_string(lifes);
    con->setCursor(ENEMY_SPAWNER_Y,ENEMY_SPAWNER_X);
    *con << space[ENEMY_SPAWNER_X][ENEMY_SPAWNER_Y];
}

void Map::MoveCharacter(Direction dir)
{   
    if(character.getDirection() != dir)
    {
        character.setDirection(dir);
    }else
    {
        if(character.getX() == 0 && character.getDirection() == Direction::Left
            || character.getX() == SIZE_X-1 && character.getDirection() == Direction::Right
            || character.getY() == 0 && character.getDirection() ==Direction::Up 
            || character.getY() == SIZE_Y-1 && character.getDirection() == Direction::Down)
        {}
        else
        {
            int x = character.getX();
            int y = character.getY();
            switch(dir)
            {
                case Direction::Left:
                    character.setX(character.getX() - 1);
                break;
                case Direction::Right:
                    character.setX(character.getX() + 1);
                break;
                case Direction::Up:
                    character.setY(character.getY() - 1);
                break;
                case Direction::Down:
                    character.setY(character.getY() + 1);
                break;
            }

            if(!character.isUntouchable(space[character.getX()][character.getY()]))
            {
                con->setCursor(y,x);
                space[x][y] = "  ";
                *con << space[x][y];
                space[character.getX()][character.getY()] = "\x2\x1";
                con->setCursor(character.getY(),character.getX());
                *con << space[character.getX()][character.getY()];
            }else
            {
                character.setX(x);
                character.setY(y);
            }

            for (int  i = 0; i < 8; i++)
            {
                if(cherries[i].compareCoords(character.getX(), character.getY()))
                {
                    score = cherries[i].ObtainCherry(score);
                }
            }
        }
    }
}

void Map::SeeApples()
{
    for (int i = 0; i < 8; i++)
    {
        if(apples[i].getY() < SIZE_Y-1 && space[apples[i].getX()][apples[i].getY() + 1] == "  ")
        {
            
            if(apples[i].isActive() && apples[i].isFalling())
            {
                //Se cae
                MoveApple(apples[i]);
            }else 
            {
                apples[i].setFall();
            }
        }else if(apples[i].isActive() && apples[i].isFalling())
        {
            if(apples[i].getY() <= SIZE_Y-1)
            {
                if(space[apples[i].getX()][apples[i].getY()] == "\x2\x1")
                {
                    lifes--;
                    //Restart GAME
                }else
                {
                    //Lo que sea
                }
            }
            space[apples[i].getX()][apples[i].getY()] = "  ";
            con->setCursor(apples[i].getY(),apples[i].getX());
            *con << space[apples[i].getX()][apples[i].getY()];
            apples[i].setOff();
        }
    }
}

void Map::MoveApple(Apple &app)
{
    space[app.getX()][app.getY()] = "  ";
    con->setCursor(app.getY(),app.getX());
    *con << space[app.getX()][app.getY()];
    app.setY(app.getY() + 1);
    space[app.getX()][app.getY()] = app.Body();
    con->setCursor(app.getY(),app.getX());
    *con << space[app.getX()][app.getY()];
}

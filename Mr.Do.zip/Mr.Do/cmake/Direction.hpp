#pragma once

enum class Direction
{
    Left, Right, Up , Down, Null
};
#include "MyGame.h"
#include "Map.hpp"
#include <thread>
#include <iostream>

void MyGame::run()
{
    Map map(&con);
    con.setForecolor(CColor::Grey);
    con.setBackcolor(CColor::Black);
    con.clearScreen();
    con.setCursor(10, 10);
    con.setForecolor(CColor::PaleGreen3);
    map.toString();
    con.flushKeybuffer();

    while (con.isActive()) {
        uint32_t key = con.getKey();

        if (key != SDLK_UNKNOWN) {
            switch (key) {
                case SDLK_LEFT:
                    map.MoveCharacter(Direction::Left);
                    break;
                case SDLK_RIGHT:
                    map.MoveCharacter(Direction::Right);
                    break;
                case SDLK_UP:
                    map.MoveCharacter(Direction::Up);
                    break;
                case SDLK_DOWN:
                    map.MoveCharacter(Direction::Down);
                    break;
                case SDLK_F1:
                    map.Shoot();
                    break;
            }
            con.refresh();
        }
    }
}
